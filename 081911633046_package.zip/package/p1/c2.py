# import file
import c1

# class C2
class C2():
    def __init__(self):
        self.o = c1.C1(2,3,4,5)


